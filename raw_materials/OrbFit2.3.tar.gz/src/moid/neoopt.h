c integrator parameters
c parametri integratore numerico
      integer ismax
      parameter (ismax=20)
      INTEGER isrk
      DOUBLE PRECISION eprk,epnod
      COMMON/neooptio/eprk,epnod,isrk
