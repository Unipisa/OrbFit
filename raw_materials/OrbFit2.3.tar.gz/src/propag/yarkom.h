c controls and directory for Yarkovski force
      INTEGER iyark,iyarpt
      CHARACTER*80 yardir
      common/yarko/iyark,iyarpt
      common/yarcar/yardir
