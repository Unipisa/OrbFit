c =============================================
c CODODE.H
c requires parobx.h 
c first derivatives of observations with respect to elements
      DOUBLE PRECISION g(nob2x,6)
      COMMON/cmcodd/g
