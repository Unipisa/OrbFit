* Program version
      CHARACTER*15 pvers
      PARAMETER (pvers='2.1.1, 2000/05/17')
