c  asteroid radius
      double precision radius
      common/astradius/radius
