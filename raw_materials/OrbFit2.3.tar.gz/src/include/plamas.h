      DOUBLE PRECISION gmpla
      COMMON /plamas/ gmpla
