c maximum number of close approaches in clo files
      INTEGER nox,ncol
      PARAMETER (nox=100000)
      PARAMETER (ncol=27)
