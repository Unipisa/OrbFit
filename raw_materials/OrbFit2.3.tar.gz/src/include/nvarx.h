c workspace maximum dimensions in propin; suitable for 1 asteroid only
      integer nvar2x,nvarx
      parameter (nvar2x=21)
      parameter (nvarx=2*nvar2x)
