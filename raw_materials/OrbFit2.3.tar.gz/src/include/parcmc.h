* Copyright (C) 1996 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: August 10, 1996
* ---------------------------------------------------------------------
* Comment character in a namelist
      CHARACTER*1 comcha
      PARAMETER (comcha='!')
