c to force restart anyway
      LOGICAL restar
      COMMON/restart/restar
