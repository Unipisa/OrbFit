c  relativistic parameters
      double precision vlight,ckm
      common/cmgrel/vlight,ckm   
