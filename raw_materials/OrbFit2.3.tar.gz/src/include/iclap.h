c cotnrol of close approach software
      integer iclap,iorb
      common/clapco/iclap,iorb
c Close approach control
      double precision dmea,dmoon,dmjup,dmast,dter
      common/clocon/dmea,dmoon,dmjup,dmast,dter
