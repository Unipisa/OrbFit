* Max number of bodies in binary ephemeris file
      INTEGER nbepx
      PARAMETER (nbepx=5)
