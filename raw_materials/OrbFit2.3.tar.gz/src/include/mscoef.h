*   multistep coefficients
      double precision c,f,b,a,cerr
      common/mscoef/c(m2max),f(m2max),b(m2max),a(m2max),cerr
