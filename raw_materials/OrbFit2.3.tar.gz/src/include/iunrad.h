c data to be used to output radar reports
      INTEGER iunrad,iunrare
      CHARACTER*9 namast
      COMMON/radrad/iunrad,iunrare,namast
