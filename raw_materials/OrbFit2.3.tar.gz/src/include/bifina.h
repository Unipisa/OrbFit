* file for asteroid constants and names
      character*80 filbec
      common/astnamfi/filbec 
