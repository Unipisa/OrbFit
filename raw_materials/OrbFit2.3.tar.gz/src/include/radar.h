c radar flag
      LOGICAL radar
      COMMON /radlog/ radar
