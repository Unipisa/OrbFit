c Version 1.8.3 A. Milani January 1999
c Dynamical Model
      INTEGER ilun,imerc,iplut,irel,icrel,iast,icast,iaber,istat
      common/model/ilun,imerc,iplut,irel,icrel,iast,icast,iaber,istat


      









