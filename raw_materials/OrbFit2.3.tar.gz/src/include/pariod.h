* Max number of methods for initial orbit determination
      INTEGER iodnmx
      PARAMETER (iodnmx=5)
