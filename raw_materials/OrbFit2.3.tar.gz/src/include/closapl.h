c 5 october 2001; A. Milani
c parameters with controls for close app.
      DOUBLE PRECISION eprdot
      COMMON/target/eprdot
* Minimum number of data points for a deep close appr
      INTEGER npoint
      COMMON/clap/npoint
