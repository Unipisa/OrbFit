c =======================================
c startup from a non close approaching state at each integration restart
      LOGICAL clost
      COMMON /clolog/clost
