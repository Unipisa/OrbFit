c ============================
c  parobx.h max number of observations
      integer nobx,nob2x
      parameter (nobx=8000,nob2x=nobx*2)
