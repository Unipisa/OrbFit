c =========================================
c {\bf parint.h} ORBIT8V
      integer ismax,itmax,mmax,m2max 
      parameter (ismax=20)
      parameter (itmax=20)
      parameter (mmax=20)
      parameter (m2max=2*mmax+2)
