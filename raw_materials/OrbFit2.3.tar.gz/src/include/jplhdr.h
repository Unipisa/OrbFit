c JPL ephemerides header common
      integer ipt(3,13),lpt(3),denum,ncon
      double precision ss(3),cval(400),au,emrat
      common/ephhdr/cval,ss,au,emrat,denum,ncon,ipt,lpt
