* Copyright (C) 1997 by A.Milani and M.Carpino
* Version: October 8, 1997
* gravitational  constant: units, mass of the Sun, day, AU
      double precision gk,gms
      parameter (gk=0.01720209895d0)
      parameter (gms=gk*gk)
