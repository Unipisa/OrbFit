c ====================================
c parmul.h : maximum number of multiple solutions
      INTEGER mulx
      PARAMETER (mulx=4001)
