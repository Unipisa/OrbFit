c derivatives of cartesian with respect to elements
      DOUBLE PRECISION dx0de(6,6)
      COMMON /derele/ dx0de
