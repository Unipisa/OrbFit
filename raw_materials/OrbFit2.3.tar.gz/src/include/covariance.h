c covariance matrix, to be used by strclan
      DOUBLE PRECISION gc(6,6)
c availability flag
      LOGICAL covava
      COMMON/covar/gc,covava
