* Copyright (C) 1997 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: November 20, 1997
* ---------------------------------------------------------------------
*
* Max number of objects (asteroids): 2 read form input + 1 for merge
      INTEGER nobjx,nobj1x
      PARAMETER (nobjx=2)
      PARAMETER (nobj1x=nobjx+1)
