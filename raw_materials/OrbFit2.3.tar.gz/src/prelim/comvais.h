c ====================================
c {\bf comvais.h} VAISALA
c  passing of data to subroutine
c
      double precision alpha(3),delta(3),xt(3),yt(3),zt(3),tjd0(3)
      double precision tjd(3),xi(3),eta(3),zeta(3)
      common/cmvai1/alpha,delta,xt,yt,zt,tjd0,tjd,xi,eta,zeta
