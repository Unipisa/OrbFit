c ====================================
c {\bf parrho.h} VAISUB
c initialisation of the search range
c initial guess on the interval containing the root
c lower limit at the Earth's sphere of influence
      double precision rho2ini1,rho2ini2,zdacc
      parameter(rho2ini1=0.0002d0)
      parameter(rho2ini2=50.d0)
c  accuracy control
      parameter(zdacc=1.d-6)
 
