* Max number of triplets for initial orbit determination
      INTEGER n3smax
      PARAMETER (n3smax=20)
