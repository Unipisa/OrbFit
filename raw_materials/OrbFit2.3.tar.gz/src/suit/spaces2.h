* Copyright (C) 1996-1998 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: January 12, 1998
* ---------------------------------------------------------------------
* List of characters to be considered as "spaces":
* blank and horizontal TAB
      DATA icspac/32,9/
