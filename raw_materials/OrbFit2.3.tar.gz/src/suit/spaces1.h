* Copyright (C) 1996 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: August 26, 1996
* ---------------------------------------------------------------------
* List of characters to be considered as "spaces"
      INTEGER nspac
      PARAMETER (nspac=2)
      INTEGER icspac(nspac)
      SAVE icspac
