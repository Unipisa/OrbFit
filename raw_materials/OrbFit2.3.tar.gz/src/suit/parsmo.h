* Copyright (C) 1999 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: November 11, 1999
* ---------------------------------------------------------------------
* Max order of smoothness for SMOOCN routine
      INTEGER nd1x,nd2x
      PARAMETER (nd1x=16)
      PARAMETER (nd2x=nd1x+1)
