* Copyright (C) 2000 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: November 15, 2000
* ---------------------------------------------------------------------
* Models of autocorrelation functions for all the observatories
*
* Max number of parameters/functions (all observatories together)
      INTEGER nparx
      PARAMETER (nparx=500)
