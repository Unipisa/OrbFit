* Copyright (C) 1999 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: November 12, 1999
* ---------------------------------------------------------------------
* Max number of data points in IERS time series
      INTEGER niersx
      PARAMETER (niersx=30000)
* Max number of separate interpolations (pcwlgi)
      INTEGER niplix
      PARAMETER (niplix=5000)
