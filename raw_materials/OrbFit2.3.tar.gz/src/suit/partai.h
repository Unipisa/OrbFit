* Copyright (C) 1996 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: August 26, 1996
* ---------------------------------------------------------------------
* Max number of records in TAI-UTC (leap second) file
      INTEGER ntaix
      PARAMETER (ntaix=50)
