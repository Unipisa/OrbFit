* Copyright (C) 1999 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: November 11, 1999
* ---------------------------------------------------------------------
* Max degree of polynomial interpolation using Legendre, Chebychev
* or similar polynomials
      INTEGER lgintx,lgin1x
      PARAMETER (lgintx=30)
      PARAMETER (lgin1x=lgintx+1)
