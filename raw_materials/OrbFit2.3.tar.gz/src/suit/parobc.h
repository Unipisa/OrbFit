* Copyright (C) 1999 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: September 7, 1999
* ---------------------------------------------------------------------
* Min and max value for observatory code
      INTEGER obsc1,obsc2
      PARAMETER (obsc1=0)
      PARAMETER (obsc2=999)
