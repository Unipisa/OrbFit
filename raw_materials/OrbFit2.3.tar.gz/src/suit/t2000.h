* Copyright (C) 1997 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: March 7, 1997
* ---------------------------------------------------------------------
*
* Epoch corresponding to J2000 (MJD, TDT)
*
      DOUBLE PRECISION t2000
      PARAMETER (t2000=51544.5d0)
