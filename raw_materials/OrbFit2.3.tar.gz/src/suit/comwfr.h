* Copyright (C) 1997 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: March 21, 1997
* ---------------------------------------------------------------------
*
* Options for writing real values to file-header namelists
*
* iicwfr   -  Initialization check
*
      INTEGER iicwfr
      COMMON/cmwrf1/iicwfr
