* Copyright (C) 1999 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: November 15, 1999
* ---------------------------------------------------------------------
* ET (TDT) - TAI (s)
      DOUBLE PRECISION etmtai
      PARAMETER (etmtai=32.184d0)
