* Copyright (C) 1996 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: August 10, 1996
* ---------------------------------------------------------------------
* Length of buffer character strings
      INTEGER lchx
      PARAMETER (lchx=200)
