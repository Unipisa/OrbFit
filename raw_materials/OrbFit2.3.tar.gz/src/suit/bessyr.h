* Copyright (C) 1999 by Mario Carpino (carpino@brera.mi.astro.it)
* Version: November 11, 1999
* ---------------------------------------------------------------------
* Besselian year
*
      DOUBLE PRECISION bessyr
      PARAMETER (bessyr=365.242198781d0)
