# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate labels original text with physical files.


1;

