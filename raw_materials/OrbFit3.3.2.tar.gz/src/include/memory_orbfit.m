nblx= 1000
nxinbl=80
nxinbl_large=400
nbl_large=50
1e-6*(nblx*(2*nxinbl_large+1)*4 + 8*nxinbl^2*nblx + 8*nxinbl_large^2*nbl_large)
